# BuildForU

BuildForU is a construction company management web application focused on helping office teams and field crews stay aligned in one workspace. The current product is an MVP frontend connected to the local backend for authentication, while operational app data still uses mock and `localStorage` data until the remaining APIs are wired in.

## Overview

BuildForU is designed as an internal operations platform for construction businesses. It provides role-based access to dashboards, workforce coordination tools, scheduling views, communication features, and market/store discovery. At this stage, login/session validation uses the backend JWT API, and the rest of the product screens continue to use local MVP data.

## Main Features

- Backend-connected JWT login flow for Boss/Admin and Employee users
- Admin dashboard for company-wide operations visibility
- Employee dashboard focused on personal assignments and field activity
- Workers management interface
- Calendar and schedule overview
- Task management
- Team chat
- Materials requests and Find to Buy store finder
- Multilingual UI
- Responsive design for desktop and mobile usage
- Local frontend persistence for workers, projects, tasks, attendance, materials, selected language, and the MVP JWT session

## Tech Stack

- React
- Vite
- Tailwind CSS
- React Router
- Backend auth API integration with mock/local operational data for the current stage

## Getting Started

### Installation

```bash
npm install
```

Create a frontend environment file:

```bash
cp .env.example .env
```

Set `VITE_API_URL` to the backend API URL. The local backend defaults to `http://localhost:4000`.

### Run Development Server

```bash
npm run dev
```

After starting the development server, open the local URL shown in the terminal.

### Production Build Check

```bash
npm run build
```

## Example Mock Login Accounts

- Admin: `admin@buildforu.com` / `admin123`
- Employee: `worker@buildforu.com` / `worker123`

These accounts come from the backend seed data. New employee logins created from the Workers screen call the backend workers API and show the temporary password returned once by the API.

## Project Structure

```text
src/
  assets/         Logos and static visual assets
  components/     Shared UI, navigation, dashboard, and auth guard components
  contexts/       Global app state providers such as auth, i18n, and mock app data
  data/           Mock datasets used across the prototype
  hooks/          Custom React hooks for accessing app contexts
  i18n/           Locale dictionaries for the multilingual interface
  layouts/        Shared application shell layouts
  pages/          Route-level screens such as dashboard, login, chat, and settings
  App.jsx         Main route composition
  main.jsx        App bootstrap entry
```

## Notes

- Authentication is connected to the backend API through JWT.
- Operational data screens still use local mock/`localStorage` data until the remaining backend endpoints are connected.
- JWT is stored in `localStorage` for the MVP only. A production deployment should review token storage, refresh/session strategy, CSRF posture, and deployment-specific security controls.
- Backend passwords are hashed, but seed/demo passwords are not production-safe credentials.
- Access control must continue to be enforced server-side; frontend role guards are only a UI convenience.
- Application data is local, resilient to empty/malformed storage, and based on mock datasets when no saved data exists.

## Future Plans

- Connect workers, projects, tasks, attendance, materials, and chat screens to the backend APIs
- Add persistent database storage
- Implement real authentication and session handling
- Support file uploads
- Integrate real maps and geolocation services
- Add AI-powered product and store search

## Development Status

BuildForU is currently positioned as a polished MVP frontend with backend-connected authentication. The UI, routing, role-based flows, and mock operational data are in place, while the next phase is connecting the remaining data screens to the backend APIs.
