import { createContext, useCallback, useEffect, useMemo, useState } from "react";
import { authApi } from "../api/auth.api";
import { ApiError } from "../api/client";
import { clearStoredAuth, getStoredUser, getToken, setStoredUser, setToken } from "../api/auth.storage";
import { workersApi } from "../api/workers.api";

export const AuthContext = createContext(null);

const DEMO_COMPANY_ID = "company-1";
const DEMO_WORKSPACE_ID = "workspace-1";

function normalizeRole(role) {
  const normalizedRole = String(role || "").toLowerCase();
  return normalizedRole === "admin" ? "admin" : "employee";
}

function createInitials(name = "") {
  const initials = name
    .trim()
    .split(/\s+/)
    .slice(0, 2)
    .map((part) => part[0]?.toUpperCase())
    .join("");

  return initials || "BU";
}

function resolveDemoWorkerId(user) {
  const email = String(user?.email || "").toLowerCase();

  if (email === "worker@buildforu.com") {
    return "u-employee-1";
  }

  return user?.workerId || null;
}

function isDemoBackendWorkspace(apiUser, company, apiCompanyId) {
  const email = String(apiUser?.email || "").toLowerCase();

  return (
    apiCompanyId === "company_demo_buildforu" ||
    company?.name === "BuildForU Demo Construction" ||
    email === "admin@buildforu.com" ||
    email === "worker@buildforu.com"
  );
}

function normalizeApiUser(apiUser) {
  if (!apiUser) {
    return null;
  }

  const role = normalizeRole(apiUser.role);
  const company = apiUser.company || null;
  const apiCompanyId = apiUser.companyId || company?.id || null;
  const apiWorkerId = apiUser.workerId || null;
  const isDemoWorkspace = isDemoBackendWorkspace(apiUser, company, apiCompanyId);
  const workerId = role === "employee" ? resolveDemoWorkerId(apiUser) : apiWorkerId;

  return {
    ...apiUser,
    role,
    company,
    companyId: apiCompanyId,
    apiCompanyId,
    workerId,
    apiWorkerId,
    workspaceId: apiUser.workspaceId || apiCompanyId || (isDemoWorkspace ? DEMO_WORKSPACE_ID : ""),
    workspaceName: apiUser.workspaceName || company?.name || apiUser.companyName || "BuildForU",
    companyName: apiUser.companyName || company?.name || "BuildForU",
    plan: apiUser.plan || company?.plan || "pro",
    avatar: apiUser.avatar || createInitials(apiUser.name),
    title: apiUser.title || (role === "admin" ? "Company Admin" : "Employee"),
    isApiBacked: true,
    mockCompanyId: isDemoWorkspace ? DEMO_COMPANY_ID : null,
    mockWorkspaceId: isDemoWorkspace ? DEMO_WORKSPACE_ID : null,
  };
}

function authErrorKey(error, context = "login") {
  if (error instanceof ApiError) {
    if (error.code === "NETWORK_ERROR") {
      return context === "register" ? "register.networkError" : "login.networkError";
    }

    if (error.status === 503 || error.code === "DATABASE_UNAVAILABLE") {
      return context === "register" ? "register.databaseUnavailable" : "login.databaseUnavailable";
    }

    if (error.status === 401) {
      return "login.invalidCredentials";
    }

    if (context === "register") {
      if (error.status === 409 || error.code === "EMAIL_IN_USE" || error.code === "UNIQUE_CONSTRAINT") {
        return "register.emailInUse";
      }

      if (error.status === 400 || error.code === "VALIDATION_ERROR") {
        return "register.validationError";
      }

      return "register.serverError";
    }

    return "login.serverError";
  }

  return error?.message || "login.serverError";
}

function mergeCompanyUser(list, nextUser) {
  if (!nextUser) {
    return list;
  }

  const exists = list.some((member) => member.id === nextUser.id || member.email === nextUser.email);

  if (exists) {
    return list.map((member) => (member.id === nextUser.id || member.email === nextUser.email ? { ...member, ...nextUser } : member));
  }

  return [...list, nextUser];
}

export function AuthProvider({ children }) {
  const [user, setUser] = useState(() => getStoredUser());
  const [isLoading, setIsLoading] = useState(true);
  const [companyUsers, setCompanyUsers] = useState(() => {
    const storedUser = getStoredUser();
    return storedUser ? [storedUser] : [];
  });

  const persistSession = useCallback((token, apiUser) => {
    const normalizedUser = normalizeApiUser(apiUser);

    if (!token || !normalizedUser) {
      clearStoredAuth();
      setUser(null);
      setCompanyUsers([]);
      return null;
    }

    setToken(token);
    setStoredUser(normalizedUser);
    setUser(normalizedUser);
    setCompanyUsers((members) => mergeCompanyUser(members, normalizedUser));

    return normalizedUser;
  }, []);

  useEffect(() => {
    let isMounted = true;

    async function bootstrapSession() {
      if (!getToken()) {
        clearStoredAuth();

        if (isMounted) {
          setUser(null);
          setCompanyUsers([]);
          setIsLoading(false);
        }

        return;
      }

      try {
        const response = await authApi.me();
        const normalizedUser = normalizeApiUser(response.user);

        if (!normalizedUser) {
          throw new Error("login.sessionExpired");
        }

        setStoredUser(normalizedUser);

        if (isMounted) {
          setUser(normalizedUser);
          setCompanyUsers((members) => mergeCompanyUser(members, normalizedUser));
        }
      } catch {
        clearStoredAuth();

        if (isMounted) {
          setUser(null);
          setCompanyUsers([]);
        }
      } finally {
        if (isMounted) {
          setIsLoading(false);
        }
      }
    }

    bootstrapSession();

    return () => {
      isMounted = false;
    };
  }, []);

  const login = useCallback(
    async ({ email, password }) => {
      try {
        const response = await authApi.login({ email, password });
        return persistSession(response.token, response.user);
      } catch (error) {
        throw new Error(authErrorKey(error, "login"));
      }
    },
    [persistSession],
  );

  const logout = useCallback(() => {
    clearStoredAuth();
    setUser(null);
    setCompanyUsers([]);
  }, []);

  const registerCompany = useCallback(
    async ({ companyName, ownerName, email, password, plan }) => {
      try {
        const response = await authApi.registerCompany({
          companyName,
          name: ownerName || `${companyName} Admin`,
          email,
          password,
          plan,
        });
        const registeredUser = persistSession(response.token, response.user);

        return {
          company: registeredUser?.company,
          credentials: { email },
          user: registeredUser,
        };
      } catch (error) {
        throw new Error(authErrorKey(error, "register"));
      }
    },
    [persistSession],
  );

  const previewAccount = useCallback((email) => {
    const normalizedEmail = String(email || "").trim().toLowerCase();

    if (!normalizedEmail) {
      return null;
    }

    if (normalizedEmail.includes("admin") || normalizedEmail.includes("boss")) {
      return { role: "admin" };
    }

    return { role: "employee" };
  }, []);

  const syncWorkerUser = useCallback(
    async (workerProfile, options = {}) => {
      if (!user || user.role !== "admin" || !workerProfile?.email) {
        return { created: false, publicUser: null, temporaryPassword: "" };
      }

      const response = await workersApi.createWorker({
        name: workerProfile.name,
        email: workerProfile.email,
        phone: workerProfile.phone || "",
        notes: workerProfile.notes || "",
        createLogin: options.createLogin !== false,
      });

      const worker = response.worker;
      const linkedUser = worker?.user;
      const publicUser = normalizeApiUser({
        id: linkedUser?.id || worker?.id,
        name: linkedUser?.name || workerProfile.name,
        email: linkedUser?.email || workerProfile.email,
        role: linkedUser?.role || "EMPLOYEE",
        companyId: user.apiCompanyId || user.companyId,
        workerId: worker?.id,
        company: user.company,
        title: "Employee",
      });

      setCompanyUsers((members) => mergeCompanyUser(members, publicUser));

      return {
        created: Boolean(response.temporaryPassword),
        publicUser,
        temporaryPassword: response.temporaryPassword || "",
      };
    },
    [user],
  );

  const removeWorkerUser = useCallback(
    async (workerId) => {
      if (!user || user.role !== "admin" || !workerId) {
        return false;
      }

      const targetMember = companyUsers.find((member) => member.apiWorkerId === workerId || member.workerId === workerId);

      if (!targetMember?.apiWorkerId && !targetMember?.workerId) {
        return false;
      }

      try {
        await workersApi.deleteWorker(targetMember.apiWorkerId || targetMember.workerId);
        setCompanyUsers((members) => members.filter((member) => member.id !== targetMember.id));
        return true;
      } catch {
        return false;
      }
    },
    [companyUsers, user],
  );

  const company = useMemo(() => {
    if (!user) {
      return null;
    }

    return {
      id: user.companyId,
      apiCompanyId: user.apiCompanyId,
      workspaceId: user.workspaceId,
      name: user.companyName,
      plan: user.plan,
    };
  }, [user]);

  const value = useMemo(
    () => ({
      user,
      currentUser: user,
      role: user?.role || null,
      workerId: user?.workerId || null,
      apiWorkerId: user?.apiWorkerId || null,
      users: companyUsers,
      companyUsers,
      companies: company ? [company] : [],
      company,
      isAuthenticated: Boolean(user),
      isLoading,
      isBooting: isLoading,
      login,
      logout,
      previewAccount,
      registerCompany,
      syncWorkerUser,
      removeWorkerUser,
    }),
    [
      company,
      companyUsers,
      isLoading,
      login,
      logout,
      previewAccount,
      registerCompany,
      removeWorkerUser,
      syncWorkerUser,
      user,
    ],
  );

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}
